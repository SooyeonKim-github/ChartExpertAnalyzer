from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from ..analysis.analyzer import ChartAnalyzer
from ..utils.logger import get_logger

logger = get_logger('RangeBacktester')


@dataclass(frozen=True)
class RangeBacktestParams:
    start_date: pd.Timestamp
    end_date: pd.Timestamp
    top_n: int = 100
    sort_by: str = 'market_cap'
    forward_bars: int = 60
    history_days: int = 1200
    min_score: float = 62.0
    min_technical: float | None = None
    min_timing: float | None = None
    max_risk: float | None = None
    cooldown_bars: int = 0


def parse_date_range(text: str) -> tuple[pd.Timestamp, pd.Timestamp]:
    raw = str(text or '').strip().replace(' ', '')
    if '~' not in raw:
        raise ValueError('기간은 YYYYMMDD~YYYYMMDD 형식으로 입력하세요. 예: 20260701~20260724')
    left, right = raw.split('~', 1)
    try:
        start = pd.to_datetime(left, format='%Y%m%d')
        end = pd.to_datetime(right, format='%Y%m%d')
    except Exception as exc:
        raise ValueError('기간은 YYYYMMDD~YYYYMMDD 형식으로 입력하세요. 예: 20260701~20260724') from exc
    if start > end:
        raise ValueError(f'시작일이 종료일보다 늦습니다: {start.date()} > {end.date()}')
    return start.normalize(), end.normalize()


def _benchmark_for_market(market: str) -> str:
    text = str(market or 'KOSPI').upper()
    return '^KQ11' if 'KOSDAQ' in text else '^KS11'


def _passes(r, params: RangeBacktestParams) -> bool:
    if r.total_score < params.min_score:
        return False
    if params.min_technical is not None and r.technical_score < params.min_technical:
        return False
    if params.min_timing is not None and r.timing_score < params.min_timing:
        return False
    if params.max_risk is not None and r.risk_score > params.max_risk:
        return False
    return True


def _forward_columns(df: pd.DataFrame, idx: int, entry: float, forward_bars: int) -> dict:
    out: dict[str, object] = {}
    available = max(0, min(forward_bars, len(df) - idx - 1))
    for h in range(1, forward_bars + 1):
        if idx + h < len(df):
            px = float(df['Close'].iloc[idx + h])
            out[f'D+{h}'] = px / entry - 1.0
        else:
            out[f'D+{h}'] = np.nan
    out['forward_available_bars'] = available
    out['forward_complete'] = bool(available >= forward_bars)
    if available:
        fwd = df.iloc[idx + 1: idx + available + 1]
        out[f'MFE_D+{forward_bars}'] = float(fwd['High'].max() / entry - 1.0)
        out[f'MAE_D+{forward_bars}'] = float(fwd['Low'].min() / entry - 1.0)
        out[f'max_close_return_D+{forward_bars}'] = float(fwd['Close'].max() / entry - 1.0)
        out[f'min_close_return_D+{forward_bars}'] = float(fwd['Close'].min() / entry - 1.0)
    else:
        out[f'MFE_D+{forward_bars}'] = np.nan
        out[f'MAE_D+{forward_bars}'] = np.nan
        out[f'max_close_return_D+{forward_bars}'] = np.nan
        out[f'min_close_return_D+{forward_bars}'] = np.nan
    return out


class RangeBacktester:
    """기간 내 각 거래일의 차트 신호를 재생하고 D+N 사후수익률을 계산한다.

    주의: Universe는 KOSPI_Info.xlsx에 담긴 현재 스냅샷을 고정해서 사용한다.
    따라서 과거 시점의 실제 시가총액 TOP N을 복원하는 백테스트가 아니라
    '현재 Universe를 과거 구간에 적용한 이벤트 스터디'다.
    """

    def __init__(self, analyzer: ChartAnalyzer, provider, universe_service):
        self.analyzer = analyzer
        self.provider = provider
        self.universe_service = universe_service

    def run(
        self,
        params: RangeBacktestParams,
        include_etf: bool = False,
    ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        if not hasattr(self.provider, 'get_ohlcv_by_date'):
            raise ValueError('기간 백테스트는 get_ohlcv_by_date를 지원하는 provider가 필요합니다. --provider pykrx를 사용하세요.')

        universe = self.universe_service.get_universe(
            top_n=params.top_n,
            sort_by=params.sort_by,
            include_etf=include_etf,
        )
        universe_df = pd.DataFrame([{
            'source_rank': x.source_rank,
            'ticker': x.ticker,
            'name': x.name,
            'market': x.market,
            'market_cap': x.market_cap,
            'trading_value': x.trading_value,
            'volume': x.volume,
        } for x in universe])

        # 120일 이평 + 주봉 교차검증을 위해 충분한 사전 히스토리를 확보한다.
        fetch_start = (params.start_date - pd.Timedelta(days=params.history_days)).strftime('%Y-%m-%d')
        # D+60 거래일 확보를 위해 약 120일의 달력 버퍼를 둔다. 미래 데이터가 아직 없으면 가능한 구간까지만 계산된다.
        forward_calendar_days = max(120, int(params.forward_bars * 2.0))
        fetch_end = (params.end_date + pd.Timedelta(days=forward_calendar_days)).strftime('%Y-%m-%d')

        benchmark_cache: dict[str, pd.DataFrame | None] = {}
        for info in universe:
            benchmark = _benchmark_for_market(info.market)
            if benchmark in benchmark_cache:
                continue
            try:
                benchmark_cache[benchmark] = self.provider.get_ohlcv_by_date(benchmark, fetch_start, fetch_end)
            except Exception as exc:
                logger.warning('%s 벤치마크 조회 실패: %s', benchmark, exc)
                benchmark_cache[benchmark] = None

        rows: list[dict] = []
        errors: list[dict] = []
        min_hist = max(self.analyzer.cfg['moving_average']['long'] + 10, 140)

        for seq, info in enumerate(universe, start=1):
            ticker = info.ticker
            benchmark = _benchmark_for_market(info.market)
            try:
                df = self.provider.get_ohlcv_by_date(ticker, fetch_start, fetch_end)
                if df.empty:
                    raise ValueError('OHLCV 데이터 없음')
                df = df[~df.index.duplicated(keep='last')].sort_index()
                market_df = benchmark_cache.get(benchmark)
                signal_positions = np.flatnonzero(
                    (df.index.normalize() >= params.start_date) &
                    (df.index.normalize() <= params.end_date)
                )
                if len(signal_positions) == 0:
                    raise ValueError('입력 기간 내 거래일 없음')

                last_signal_idx: int | None = None
                signal_count = 0
                for idx in signal_positions:
                    idx = int(idx)
                    if idx < min_hist - 1:
                        continue
                    if params.cooldown_bars > 0 and last_signal_idx is not None and idx - last_signal_idx <= params.cooldown_bars:
                        continue
                    sub = df.iloc[:idx + 1]
                    if market_df is not None and not market_df.empty:
                        market_sub = market_df.loc[market_df.index <= df.index[idx]]
                    else:
                        market_sub = None
                    try:
                        r = self.analyzer.analyze(ticker, sub, market_sub)
                    except Exception as exc:
                        errors.append({
                            'ticker': ticker, 'name': info.name,
                            'date': str(df.index[idx].date()), 'stage': 'analyze', 'error': str(exc),
                        })
                        continue
                    if not _passes(r, params):
                        continue

                    entry = float(df['Close'].iloc[idx])
                    row = {
                        'signal_date': pd.Timestamp(df.index[idx]).normalize(),
                        'ticker': ticker,
                        'name': info.name,
                        'market': info.market,
                        'source_rank': info.source_rank,
                        'market_cap': info.market_cap,
                        'entry_close': entry,
                        'selection_score': r.total_score,
                        'selection_grade': r.grade,
                        'technical_score': r.technical_score,
                        'technical_grade': r.technical_grade,
                        'timing_score': r.timing_score,
                        'timing_grade': r.timing_grade,
                        'risk_score': r.risk_score,
                        'risk_level': r.risk_level,
                        'confluence_score': r.confluence_score,
                        'entry_status': r.entry_status,
                        'chase_risk': r.chase_risk,
                        'market_regime': r.market_regime,
                        'stop_price': r.stop_price,
                        'trailing_stop_price': r.trailing_stop_price,
                        'bullish_signals': sum(1 for s in r.signals if s.score > 0),
                        'bearish_signals': sum(1 for s in r.signals if s.score < 0),
                        'top_strengths': ' | '.join(r.strengths[:3]),
                        'top_risks': ' | '.join(r.risks[:3]),
                    }
                    row.update(_forward_columns(df, idx, entry, params.forward_bars))
                    rows.append(row)
                    signal_count += 1
                    last_signal_idx = idx

                logger.info('[%d/%d] %s %s 완료 | 기간내 신호 %d건', seq, len(universe), ticker, info.name, signal_count)
            except Exception as exc:
                errors.append({'ticker': ticker, 'name': info.name, 'date': '', 'stage': 'load', 'error': str(exc)})
                logger.warning('[%d/%d] %s %s 실패: %s', seq, len(universe), ticker, info.name, exc)

        events = pd.DataFrame(rows)
        if not events.empty:
            events['daily_rank'] = events.groupby('signal_date')['selection_score'].rank(method='first', ascending=False).astype(int)
            front = [
                'signal_date', 'daily_rank', 'ticker', 'name', 'market', 'source_rank', 'market_cap', 'entry_close',
                'selection_score', 'selection_grade', 'technical_score', 'technical_grade', 'timing_score', 'timing_grade',
                'risk_score', 'risk_level', 'confluence_score', 'entry_status', 'chase_risk', 'market_regime',
                'stop_price', 'trailing_stop_price', 'bullish_signals', 'bearish_signals', 'top_strengths', 'top_risks',
                'forward_available_bars', 'forward_complete', f'MFE_D+{params.forward_bars}', f'MAE_D+{params.forward_bars}',
                f'max_close_return_D+{params.forward_bars}', f'min_close_return_D+{params.forward_bars}',
            ]
            return_cols = [f'D+{h}' for h in range(1, params.forward_bars + 1)]
            events = events[[c for c in front if c in events.columns] + return_cols]
            events = events.sort_values(['signal_date', 'daily_rank', 'selection_score'], ascending=[True, True, False]).reset_index(drop=True)

        summary = build_forward_summary(events, params.forward_bars)
        errors_df = pd.DataFrame(errors)
        return events, summary, universe_df, errors_df


def build_forward_summary(events: pd.DataFrame, forward_bars: int = 60) -> pd.DataFrame:
    rows: list[dict] = []
    if events.empty:
        return pd.DataFrame(columns=['horizon', 'valid_count', 'avg_return', 'median_return', 'win_rate', 'loss_rate', 'std_return'])
    for h in range(1, forward_bars + 1):
        c = f'D+{h}'
        s = pd.to_numeric(events[c], errors='coerce').dropna()
        rows.append({
            'horizon': c,
            'trading_days': h,
            'valid_count': int(s.size),
            'avg_return': float(s.mean()) if len(s) else np.nan,
            'median_return': float(s.median()) if len(s) else np.nan,
            'win_rate': float((s > 0).mean()) if len(s) else np.nan,
            'loss_rate': float((s < 0).mean()) if len(s) else np.nan,
            'std_return': float(s.std(ddof=0)) if len(s) else np.nan,
            'best_return': float(s.max()) if len(s) else np.nan,
            'worst_return': float(s.min()) if len(s) else np.nan,
        })
    return pd.DataFrame(rows)


def key_horizon_summary(summary: pd.DataFrame, horizons: Iterable[int] = (1, 5, 10, 20, 40, 60)) -> pd.DataFrame:
    wanted = {f'D+{int(h)}' for h in horizons}
    if summary.empty:
        return summary.copy()
    return summary[summary['horizon'].isin(wanted)].copy().reset_index(drop=True)
